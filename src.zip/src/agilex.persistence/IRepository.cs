using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace agilex.persistence
{
    public interface IRepository : IDisposable
    {
        int Count<T>() where T : class;
        int Count<T>(Expression<Func<T, bool>> predicate) where T : class;
        T Get<T>(Guid id) where T : class;
        T Get<T>(int id) where T : class;
        T Get<T>(long id) where T : class;
        bool Exists<T>(int id) where T : class;
        IEnumerable<T> GetAll<T>() where T : class;
        IQueryable<T> Query<T>() where T : class;
        void Save<T>(T entity) where T : class;
        void Delete<T>(T entity) where T : class;
        void BeginTransaction();
        void Commit();
        void Rollback();
        T GetOrThrowNotFound<T>(Guid id) where T : class;
        T GetOrThrowNotFound<T>(int id) where T : class;
        T GetOrThrowNotFound<T>(long id) where T : class;
    }
}