namespace agilex.persistence
{
    public enum Dialect
    {
        Oracle10,
        SqlServer2008,
        MySQL,
        Postgres,
        SqlServer2005,
        Oracle9,
        SqlLite
    }
}