﻿namespace agilex.persistence
{
    public interface ITypedRepositoryLocator
    {
        ITypedRepository<T> RepositoryInstance<T>() where T: class; 
    }
}