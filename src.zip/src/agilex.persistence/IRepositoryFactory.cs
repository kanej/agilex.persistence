namespace agilex.persistence
{
    public interface IRepositoryFactory
    {
        IRepository Instance();
        ITypedRepository<T> Instance<T>() where T: class;
    }
}