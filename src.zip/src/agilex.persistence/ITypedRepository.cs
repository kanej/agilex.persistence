using System;
using System.Collections.Generic;
using System.Linq;

namespace agilex.persistence
{
    public interface ITypedRepository<T> : IDisposable where T : class
    {
        int Count();
        T Get(Guid id);
        T Get(int id);
        T Get(long id);
        bool Exists(int id);
        IEnumerable<T> GetAll();
        IQueryable<T> Query();
        void Save(T entity);
        void Delete(T entity);
        void BeginTransaction();
        void Commit();
        void Rollback();
        T GetOrThrowNotFound(Guid id);
        T GetOrThrowNotFound(int id);
        T GetOrThrowNotFound(long id);
    }
}