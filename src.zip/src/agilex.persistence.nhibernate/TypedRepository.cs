using System;
using System.Collections.Generic;
using System.Linq;

namespace agilex.persistence.nhibernate
{
    public class TypedRepository<T> : ITypedRepository<T> where T : class
    {
        readonly IRepository _repository;

        public TypedRepository(IRepository repository)
        {
            _repository = repository;
        }

        #region ITypedRepository<T> Members

        public void Dispose()
        {
            _repository.Dispose();
        }

        public int Count()
        {
            return _repository.Count<T>();
        }

        public T Get(Guid id)
        {
            return _repository.Get<T>(id);
        }

        public T Get(int id)
        {
            return _repository.Get<T>(id);
        }

        public T Get(long id)
        {
            return _repository.Get<T>(id);
        }

        public bool Exists(int id)
        {
            return _repository.Exists<T>(id);
        }

        public IEnumerable<T> GetAll()
        {
            return _repository.GetAll<T>();
        }

        public IQueryable<T> Query()
        {
            return _repository.Query<T>();
        }

        public void Save(T entity)
        {
            _repository.Save(entity);
        }

        public void Delete(T entity)
        {
            _repository.Delete(entity);
        }

        public void BeginTransaction()
        {
            _repository.BeginTransaction();
        }

        public void Commit()
        {
            _repository.Commit();
        }

        public void Rollback()
        {
            _repository.Rollback();
        }

        public T GetOrThrowNotFound(Guid id)
        {
            return _repository.GetOrThrowNotFound<T>(id);
        }

        public T GetOrThrowNotFound(int id)
        {
            return _repository.GetOrThrowNotFound<T>(id);
        }

        public T GetOrThrowNotFound(long id)
        {
            return _repository.GetOrThrowNotFound<T>(id);
        }

        #endregion
    }
}